
package sistemagestionaventureros;


public class AventureroDuplicadoException extends Exception{
    
    public final static String DEFAULT_MENSAJE = "El aventurero esta duplicado";
    
    public AventureroDuplicadoException(){
        this(DEFAULT_MENSAJE);
    }
    
    public AventureroDuplicadoException(String mensaje){
        super(mensaje);
    }
}
