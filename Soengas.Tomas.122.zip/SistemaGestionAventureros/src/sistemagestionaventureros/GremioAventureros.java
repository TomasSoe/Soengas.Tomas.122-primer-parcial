
package sistemagestionaventureros;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class GremioAventureros {
    
    private final String nombre;
    private final List<Aventurero> aventureros;

    public GremioAventureros(String nombre) {
        Objects.requireNonNull(nombre);
        this.nombre = nombre;
        aventureros = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    
    public void agregarAventurero(Aventurero a) throws AventureroDuplicadoException{
        Objects.requireNonNull(a);        
        if(aventureros.contains(a)){
            throw new AventureroDuplicadoException("");
        }
        aventureros.add(a);
    }
        
    public List<Aventurero> obtenerAventureros(){
        return new ArrayList<>(aventureros);
    }
    
    public List<Aventurero> filtrarPorRango(Rango rango){
        List<Aventurero> resultado = new ArrayList<>();
        
        for(Aventurero a : aventureros){
            if(a.getRango() == rango){
                resultado.add(a);
            }
        }
        return resultado;
    }
    
    public List<Aventurero> obtenerAventurerosPoderosos(int poderMinimo){
        List<Aventurero> resultado = new ArrayList<>();
        
        for (Aventurero a : aventureros){
            if(a.calcularPoderCombate() >= poderMinimo){
                resultado.add(a);
            }
        }
        return resultado;
    }

    @Override
    public String toString() {
        return "GremioAventureros{" + "nombre=" + nombre + ", aventureros=" + aventureros + '}';
    }
    
    
    
}
