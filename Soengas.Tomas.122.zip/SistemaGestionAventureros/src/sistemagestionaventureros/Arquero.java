
package sistemagestionaventureros;

import java.util.Objects;


public class Arquero extends Aventurero implements Entrenable{
    
    private final int precision;

    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        Objects.requireNonNull(codigo);        
        validarNombre(nombre);
        validarInt(precision);
        Objects.requireNonNull(rango);
        super(codigo, nombre, rango);
        this.precision = precision;
    }

    public int getPoder() {
        return precision;
    }

    @Override
    public void atacar() {
        System.out.println("El arquero " + getNombre() + " carga una flecha, apunta, dispara e inflige " + calcularPoderCombate() + " puntos de danio.");
    }

    @Override
    public int calcularPoderCombate() {
        return precision * 3;
    }

    @Override
    public void entrenar() {
        System.out.println("El arquero " + getNombre() + " esta mejorando su punteria...");
    }
    
    
    

    
}
