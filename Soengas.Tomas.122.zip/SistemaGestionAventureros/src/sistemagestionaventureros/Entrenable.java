
package sistemagestionaventureros;


public interface Entrenable {
    
    public abstract void entrenar();
    
}
