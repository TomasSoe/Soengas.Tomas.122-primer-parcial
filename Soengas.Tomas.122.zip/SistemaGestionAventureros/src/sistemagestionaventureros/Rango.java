
package sistemagestionaventureros;


public enum Rango {
    
    BRONCE,
    PLATA,
    ORO
    
}
