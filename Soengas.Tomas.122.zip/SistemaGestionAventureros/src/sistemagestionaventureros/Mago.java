
package sistemagestionaventureros;

import java.util.Objects;


public class Mago extends Aventurero{
    
    private final int mana;

    public Mago(String codigo, String nombre, Rango rango, int mana) {
        Objects.requireNonNull(codigo);        
        validarNombre(nombre);
        validarInt(mana);
        Objects.requireNonNull(rango);
        super(codigo, nombre, rango);
        this.mana = mana;
    }

    public int getPoder() {
        return mana;
    }

    @Override
    public void atacar() {
        System.out.println("El mago " + getNombre() + " canaliza un poderozo hechizo e inflige " + calcularPoderCombate() + " puntos de danio.");
    }

    @Override
    public int calcularPoderCombate() {
        return mana + 10;
    }
    
    
   
    
    
}
