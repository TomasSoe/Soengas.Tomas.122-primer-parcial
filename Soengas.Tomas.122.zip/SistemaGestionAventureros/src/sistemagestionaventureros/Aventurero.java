
package sistemagestionaventureros;

import java.util.Objects;


public abstract class Aventurero {
    
    private final String codigo;
    private final String nombre;
    private final Rango rango;

    public Aventurero(String codigo, String nombre, Rango rango) {
        Objects.requireNonNull(codigo);
        Objects.requireNonNull(nombre);
        Objects.requireNonNull(rango);
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }
    
    public abstract void atacar();
    public abstract int calcularPoderCombate();
    public abstract int getPoder();

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }

    public static void validarInt(int n){
        Objects.requireNonNull(n);
        if(n <= 0){
            throw new IllegalArgumentException("El valor debe ser mayor a 0");
        }        
    }
    
    public static void validarNombre(String n){
        Objects.requireNonNull(n);
        if(n.isBlank()){
            throw new IllegalArgumentException("Nombre no valido");
        }        
    }

    @Override
    public String toString() {
        return "Aventurero{" + "codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango + '}';
    }
    
    
    @Override
    public boolean equals(Object o){
        if(o == null){
            return false;
        }
        if(o == this){
            return true;
        }
        if(o instanceof Aventurero otro){
            return codigo.equals(otro.codigo) && nombre.equals(otro.nombre);
        }
        return false;
    }
    
    
    
}
