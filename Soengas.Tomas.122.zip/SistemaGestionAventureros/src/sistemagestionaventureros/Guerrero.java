
package sistemagestionaventureros;

import java.util.Objects;


public class Guerrero extends Aventurero implements Entrenable{
    
    private final int fuerza;

    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        Objects.requireNonNull(codigo);        
        validarNombre(nombre);
        validarInt(fuerza);
        Objects.requireNonNull(rango);        
        super(codigo, nombre, rango);
        this.fuerza = fuerza;
    }

    public int getPoder() {
        return fuerza;
    }

    @Override
    public void atacar() {
        System.out.println("El guerrero " + getNombre() + " embiste con su espada e inflige " + calcularPoderCombate() + " puntos de danio.");
    }

    @Override
    public int calcularPoderCombate() {
        return fuerza * 2;
    }

    @Override
    public void entrenar() {
        System.out.println("El guerrero " + getNombre() + " esta poniendo a prueba su fuerza...");
    }


    
    
    
    
}
